Name:      CreateM3U

Version:   0.1.1

-----------------------------------------------------------------------

Intention: Create .m3u playlists with drag&drop of files and folders.
           For each folder a single .m3u file is created named after
           this folder. It will not replace already existing playlists
           of that name. The generated playlists do not contain EXTM3U
           information because a simple .m3u is nothing more than a
           text file with a list of file names per line. The initial
           tool for this task for me was a batch file ;-)

           As the generated playlists only include filenames without
           any path, as they are located along with the media files,
           they can be moved together with the files, for example for
           portable mp3 player usage.

Features:  * Creates .m3u playlists for each folder.
           * Recursivly works on all included subfolders.
           * Creates .m3u playlist for dropped files.
           * Playlist named after folder name.
           * Preserves existing playlists (by the same name).
           * Only includes audio files.
           * Playlists are sorted by filename.
           * Can be configured (a bit) in .ini file.

Usage:     Drag files and folders onto compiled CreateM3U.exe (or a
           shortcut to it). This is limited, you can double click to
           open a window with an less limited drag and drop area
           instead. 

Problem:   There are limits on submitting file/folder names to the
           program using drag&drop. AutoIt is limited to 64 (in former
           versions to 99) parameters and the total length of command
           line is limited through operating systems (I *guess* about
           2000 chars before XP, about 4000 with XP or later) - a limit
           hit very easy, as every file is part with full path. As I
           cannot handle the system limit in program as it will not be
           called in case I included an alternative way to submit
           files/folders to the program: Starting it without drag&drop
           will open a window offering a "drop zone" without alike
           limitations. AFAIK the limit of this area is about 32 kbyte,
           which should be mostly enough.
           http://www.autoitscript.com/forum/index.php?showtopic=26413

Author:    Thorsten Duhn <freeware@editorial.de>

WWW:       http://lostfound.raum108.de/create_m3u/

License:   GNU GENERAL PUBLIC LICENSE
           http://www.fsf.org/licensing/licenses/gpl.html

Compiler:  AutoIt 3.2.0.1
           http://www.autoitscript.com/

           Even with AutoIt installed you cannot drop directly to
           .au3 script. As workaround create a batch with this line:
           [AutoIt3.exe] [CreateM3U.au3] %1 %2 %3 %4 %5 %6 %7 %8 %9
           - where [*] are replaced with full paths (without []) and
           you are limited to nine files/folders to drop.

Known bug: NONE

To do:     * Better "About" box including help.
           * Is EXTM3U possible and useful?
           * Compile resources to .dll?
             (AutoIt does not support reading bitmap from .dll yet.)

-----------------------------------------------------------------------

History:

0.1.1 (2006-10-14)
      - Bugfix:  Incorrect line break at end of file (@LF instead of @CRLF)
      - Misc:    Updated AutoIt compiler (from 3.1.1.124 beta)

0.1.0 (2006-05-29)
      - Feature: GUI file drop box
                 (as reaction to command line limitations, read above)
      - Misc:    A bit cleanup...

0.0.2 (2006-05-21)
      - Feature: Progress bar while working
      - Bugfix:  Avoid possibility of directory junction loops
                 (checks directory depth, on depth of 128 directories
                 recursion is stopped)
      - Bugfix:  Creation of empty filelists 
                 (for an empty array $array[0] is "0")

0.0.1 (2006-05-18) - Initial release
